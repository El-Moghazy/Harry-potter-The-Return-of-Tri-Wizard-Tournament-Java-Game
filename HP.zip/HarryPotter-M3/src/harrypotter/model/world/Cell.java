package harrypotter.model.world;

public abstract class Cell {

}
