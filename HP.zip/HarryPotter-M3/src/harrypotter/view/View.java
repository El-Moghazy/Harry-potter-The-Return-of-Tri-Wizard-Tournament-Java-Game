package harrypotter.view;

public interface View {
	

}
