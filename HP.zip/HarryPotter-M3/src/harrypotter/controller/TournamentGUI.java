package harrypotter.controller;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

//import javax.print.attribute.standard.Media;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineEvent;
import javax.sound.sampled.LineListener;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import harrypotter.model.character.Champion;
import harrypotter.model.character.GryffindorWizard;
import harrypotter.model.character.HufflepuffWizard;
import harrypotter.model.character.RavenclawWizard;
import harrypotter.model.character.SlytherinWizard;
import harrypotter.model.character.Wizard;
import harrypotter.model.magic.DamagingSpell;
import harrypotter.model.magic.HealingSpell;
import harrypotter.model.magic.RelocatingSpell;
import harrypotter.model.magic.Spell;
import harrypotter.model.tournament.TaskListener;
import harrypotter.model.tournament.Tournament;
import harrypotter.view.gameStratUpFrame;

//import javafx.scene.media.Media;
//import javafx.scene.media.MediaPlayer;

public class TournamentGUI implements TaskListener, ActionListener {

	private gameStratUpFrame mainView;
	private Tournament tr;
	JButton finish;
	JButton quit;
	Controller controller ;

	JPanel c;
	JPanel c2;
	JPanel c3;

	JTextField name1;
	JTextField name2;
	JTextField name3;
	JTextField name4;

	JList spelllist1;
	JList spelllist2;
	JList spelllist3;
	JList spelllist4;
	JList spelllist5;
	JList spelllist52;
	JList spelllist53;
	JList spelllist54;

	ImagePanel panel2;
	ImagePanel panel3;
	ImagePanel panel4;
	ImagePanel panel5;

	Clip clip = null;
	Clip clip2 = null;
	// private ArrayList<JButton> btnsProduct;

	@SuppressWarnings("deprecation")
	public TournamentGUI() throws IOException {
		// UIManager.put("List.focusCellHighlightBorder",
		// BorderFactory.createEmptyBorder());
		 mainView = new gameStratUpFrame();

//		try {
//			AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(new File("Noddinagushpa.wav"));
//			clip = AudioSystem.getClip();
//			clip.open(audioInputStream);
//			clip.start();
//			// clip.loop(5);
//		} catch (Exception ex) {
//			ex.printStackTrace();
//		}
//		try {
//			AudioInputStream audioInputStream = AudioSystem
//					.getAudioInputStream(new File("MajorRewriteGeneralChunks.wav"));
//			clip2 = AudioSystem.getClip();
//			clip2.open(audioInputStream);
//			// clip.start();
//			// clip.loop(5);
//		} catch (Exception ex) {
//			ex.printStackTrace();
//		}
//
//		clip.addLineListener(new LineListener() {
//
//			@Override
//			public void update(LineEvent event) {
//				if (!(clip.isRunning())) {
//					clip2.start();
//					clip2.loop(10);
//				}
//			}
//		});

		c = mainView.getPanel();

		tr = new Tournament();
		name1 = new JTextField();
		name1.setText("Player1");
		name1.setFont(new Font("Brush Script MT", Font.BOLD, 24));
		name1.setSize(new Dimension(150, 17));
		c.add(name1).setLocation(400, 619);
		name1.setOpaque(false);
		name1.setBorder(null);

		name2 = new JTextField();
		name2.setText("Player2");
		name2.setFont(new Font("Brush Script MT", Font.BOLD, 24));
		name2.setSize(new Dimension(150, 17));
		c.add(name2).setLocation(860, 619);
		name2.setOpaque(false);
		name2.setBorder(null);

		name3 = new JTextField();
		name3.setText("Player3");
		name3.setFont(new Font("Brush Script MT", Font.BOLD, 24));
		name3.setSize(new Dimension(150, 17));
		c.add(name3).setLocation(400, 775);
		name3.setOpaque(false);
		name3.setBorder(null);

		name4 = new JTextField();
		name4.setText("Player4");
		name4.setFont(new Font("Brush Script MT", Font.BOLD, 24));
		name4.setSize(new Dimension(150, 17));
		c.add(name4).setLocation(860, 765);
		name4.setOpaque(false);
		name4.setBorder(null);

		finish = new JButton("Next");
		finish.setFont(new Font("Brush Script MT", Font.BOLD, 27));
		finish.setBackground(Color.WHITE);
		finish.setSize(new Dimension(90, 50));
		finish.setActionCommand("finish");
		finish.setOpaque(false);
		finish.setBorderPainted(false);
		finish.addActionListener(this);
		c.add(finish).setLocation(793, 890);

		quit = new JButton("Quit Game");
		quit.setFont(new Font("Brush Script MT", Font.BOLD, 27));
		quit.setBackground(Color.WHITE);
		quit.setSize(new Dimension(300, 70));
		quit.setActionCommand("Quit");
		quit.setOpaque(false);
		quit.setBorderPainted(false);
		quit.addActionListener(this);
		c.add(quit).setLocation(100, 900);

		final DefaultListModel model1 = new DefaultListModel();
		spelllist1 = new JList(model1);
		spelllist1.setFont(new Font("Brush Script MT", Font.BOLD, 17));
		spelllist1.setDragEnabled(false);
		spelllist1.setOpaque(false);
		spelllist1.setSize(new Dimension(130, 70));
		model1.addElement("Here 1 ");
		spelllist1.setEnabled(true);
		spelllist1.setBackground(new Color(0, 255, 0, 0));
		c.add(spelllist1).setLocation(337, 820);

		final DefaultListModel model2 = new DefaultListModel();
		spelllist2 = new JList(model2);
		spelllist2.setFont(new Font("Brush Script MT", Font.BOLD, 17));
		spelllist2.setDragEnabled(false);
		spelllist2.setOpaque(false);
		spelllist2.setSize(new Dimension(130, 70));
		model2.addElement("Here 2");
		spelllist2.setEnabled(true);
		spelllist2.setBackground(new Color(0, 255, 0, 0));
		c.add(spelllist2).setLocation(790, 810);

		final DefaultListModel model3 = new DefaultListModel();
		spelllist3 = new JList(model3);
		spelllist3.setFont(new Font("Brush Script MT", Font.BOLD, 17));
		spelllist3.setDragEnabled(false);
		spelllist3.setOpaque(false);
		spelllist3.setSize(new Dimension(130, 70));
		model3.addElement("Here 3");
		spelllist3.setEnabled(true);
		spelllist3.setBackground(new Color(0, 255, 0, 0));
		c.add(spelllist3).setLocation(790, 665);

		final DefaultListModel model4 = new DefaultListModel();
		spelllist4 = new JList(model4);
		spelllist4.setFont(new Font("Brush Script MT", Font.BOLD, 17));
		spelllist4.setDragEnabled(false);
		spelllist4.setEnabled(true);
		model4.addElement("Here 4");
		spelllist4.setSize(new Dimension(130, 70));
		spelllist4.setVisible(true);
		spelllist4.setOpaque(false);
		spelllist4.setBackground(new Color(0, 255, 0, 0));
		c.add(spelllist4).setLocation(337, 662);
		ArrayList<Spell> spells = tr.getSpells();
		Image image = (new ImageIcon(((new ImageIcon("src/spellBook.png")
				.getImage().getScaledInstance(2000, 2000, java.awt.Image.SCALE_DEFAULT))))).getImage();

		ArrayList<Spell> spells1 = new ArrayList<Spell>();
		ArrayList<Spell> spells2 = new ArrayList<Spell>();
		ArrayList<Spell> spells3 = new ArrayList<Spell>();
		ArrayList<Spell> spells4 = new ArrayList<Spell>();

		for (Spell spell : spells) {
			if (spell instanceof DamagingSpell) {
				spells1.add(new DamagingSpell(spell.getName(), spell.getCost(), spell.getCoolDown(),
						((DamagingSpell) spell).getDamageAmount()));
				spells2.add(new DamagingSpell(spell.getName(), spell.getCost(), spell.getCoolDown(),
						((DamagingSpell) spell).getDamageAmount()));
				spells3.add(new DamagingSpell(spell.getName(), spell.getCost(), spell.getCoolDown(),
						((DamagingSpell) spell).getDamageAmount()));
				spells4.add(new DamagingSpell(spell.getName(), spell.getCost(), spell.getCoolDown(),
						((DamagingSpell) spell).getDamageAmount()));
			} else if (spell instanceof HealingSpell) {
				spells1.add(new HealingSpell(spell.getName(), spell.getCost(), spell.getCoolDown(),
						((HealingSpell) spell).getHealingAmount()));
				spells2.add(new DamagingSpell(spell.getName(), spell.getCost(), spell.getCoolDown(),
						((HealingSpell) spell).getHealingAmount()));
				spells3.add(new DamagingSpell(spell.getName(), spell.getCost(), spell.getCoolDown(),
						((HealingSpell) spell).getHealingAmount()));
				spells4.add(new DamagingSpell(spell.getName(), spell.getCost(), spell.getCoolDown(),
						((HealingSpell) spell).getHealingAmount()));
			} else {
				spells1.add(new RelocatingSpell(spell.getName(), spell.getCost(), spell.getCoolDown(),
						((RelocatingSpell) spell).getRange()));
				spells2.add(new DamagingSpell(spell.getName(), spell.getCost(), spell.getCoolDown(),
						((RelocatingSpell) spell).getRange()));
				spells3.add(new DamagingSpell(spell.getName(), spell.getCost(), spell.getCoolDown(),
						((RelocatingSpell) spell).getRange()));
				spells4.add(new DamagingSpell(spell.getName(), spell.getCost(), spell.getCoolDown(),
						((RelocatingSpell) spell).getRange()));

			}

		}
		spelllist5 = new JList(toArray(spells1));
		spelllist5.setDragEnabled(false);
		spelllist5.setEnabled(true);
		spelllist5.setSize(new Dimension(200, 500));
		spelllist5.setVisible(true);
		spelllist5.setFont(new Font("Brush Script MT", Font.BOLD, 15));
		spelllist5.setOpaque(false);
		spelllist5.setBackground(new Color(0, 255, 0, 0));

		spelllist52 = new JList(toArray(spells2));
		spelllist52.setDragEnabled(false);
		spelllist52.setEnabled(true);
		spelllist52.setSize(new Dimension(200, 500));
		spelllist52.setVisible(true);
		spelllist52.setFont(new Font("Brush Script MT", Font.BOLD, 15));
		spelllist52.setOpaque(false);
		spelllist52.setBackground(new Color(0, 255, 0, 0));

		spelllist53 = new JList(toArray(spells3));
		spelllist53.setDragEnabled(false);
		spelllist53.setEnabled(true);
		spelllist53.setSize(new Dimension(200, 500));
		spelllist53.setVisible(true);
		spelllist53.setFont(new Font("Brush Script MT", Font.BOLD, 15));
		spelllist53.setOpaque(false);
		spelllist53.setBackground(new Color(0, 255, 0, 0));

		spelllist54 = new JList(toArray(spells4));
		spelllist54.setDragEnabled(false);
		spelllist54.setEnabled(true);
		spelllist54.setSize(new Dimension(200, 500));
		spelllist54.setVisible(true);
		spelllist54.setFont(new Font("Brush Script MT", Font.BOLD, 15));
		spelllist54.setOpaque(false);
		spelllist54.setBackground(new Color(0, 255, 0, 0));

		JTextArea j = new JTextArea();
		JTextArea j2 = new JTextArea();
		JTextArea j3 = new JTextArea();
		JTextArea j4 = new JTextArea();
		j.setEditable(false);
		j2.setEditable(false);
		j3.setEditable(false);
		j4.setEditable(false);
		j.setOpaque(false);
		j.setSize(new Dimension(200, 350));
		j.setLineWrap(true);
		j.setFont(new Font("Brush Script MT", Font.BOLD, 15));
		j.setText(
				"There are three types of spells Damaging spell(DMG) Relocating spell(REL) and Healing spell HEL\nThe Damaging spell is affects the target with the damaging amount"
						+ ".\nthe Relocating spell moves an to another cell according to the given range and the Healing spell increases the HP of the Wizard.\n Regards");

		j2.setOpaque(false);
		j2.setSize(new Dimension(200, 350));
		j2.setLineWrap(true);
		j2.setFont(new Font("Brush Script MT", Font.BOLD, 15));
		j2.setText(
				"There are three types of spells Damaging spell(DMG) Relocating spell(REL) and Healing spell HEL\nThe Damaging spell is affects the target with the damaging amount"
						+ ".\nthe Relocating spell moves an to another cell according to the given range and the Healing spell increases the HP of the Wizard.\n Regards");
		j3.setOpaque(false);
		j3.setSize(new Dimension(200, 350));
		j3.setLineWrap(true);
		j3.setFont(new Font("Brush Script MT", Font.BOLD, 15));
		j3.setText(
				"There are three types of spells Damaging spell(DMG) Relocating spell(REL) and Healing spell HEL\nThe Damaging spell is affects the target with the damaging amount"
						+ ".\nthe Relocating spell moves an to another cell according to the given range and the Healing spell increases the HP of the Wizard.\n Regards");
		j4.setOpaque(false);
		j4.setSize(new Dimension(200, 350));
		j4.setLineWrap(true);
		j4.setFont(new Font("Brush Script MT", Font.BOLD, 15));
		j4.setText(
				"There are three types of spells Damaging spell(DMG) Relocating spell(REL) and Healing spell HEL\nThe Damaging spell is affects the target with the damaging amount"
						+ ".\nthe Relocating spell moves an to another cell according to the given range and the Healing spell increases the HP of the Wizard.\n Regards");
		panel2 = new ImagePanel(image);
		panel2.setSize(new Dimension(500, 600));
		panel2.setLayout(null);
		// c.add(panel2).setLocation(100, 100);
		panel2.add(spelllist5).setLocation(50, 79);

		panel3 = new ImagePanel(image);
		panel3.setSize(new Dimension(500, 600));
		panel3.setLayout(null);
		// c.add(panel3).setLocation(100, 100);
		panel3.add(spelllist52).setLocation(50 , 79);

		panel4 = new ImagePanel(image);
		panel4.setSize(new Dimension(500, 600));
		panel4.setLayout(null);
		// c.add(panel4).setLocation(100, 100);
		panel4.add(spelllist53).setLocation(50, 79);

		panel5 = new ImagePanel(image);
		panel5.setSize(new Dimension(500, 600));
		panel5.setLayout(null);
		// c.add(panel5).setLocation(100, 100);
		panel5.add(spelllist54).setLocation(50, 79);

		// panel2.add(spelllist5).setLocation(100, 100);

		spelllist5.addListSelectionListener(new ListSelectionListener() {
			@Override
			public void valueChanged(ListSelectionEvent e) {
				if (!e.getValueIsAdjusting()) {
					if (model1.getSize() < 3)
						model1.addElement(spelllist5.getSelectedValue());
					else {
						panel2.setVisible(false);
						c.remove(panel2);
					}
				}
			}

		});

		spelllist52.addListSelectionListener(new ListSelectionListener() {
			@Override
			public void valueChanged(ListSelectionEvent e) {
				if (!e.getValueIsAdjusting()) {
					if (model2.getSize() < 3)
						model2.addElement(spelllist52.getSelectedValue());
					else {
						panel3.setVisible(false);
						c.remove(panel3);
					}
				}
			}

		});

		spelllist53.addListSelectionListener(new ListSelectionListener() {
			@Override
			public void valueChanged(ListSelectionEvent e) {
				if (!e.getValueIsAdjusting()) {
					if (model3.getSize() < 3)
						model3.addElement(spelllist53.getSelectedValue());
					else {
						panel4.setVisible(false);
						c.remove(panel4);
					}
				}
			}

		});

		spelllist54.addListSelectionListener(new ListSelectionListener() {
			@Override
			public void valueChanged(ListSelectionEvent e) {
				if (!e.getValueIsAdjusting()) {
					if (model4.getSize() < 3)
						model4.addElement(spelllist54.getSelectedValue());
					else {
						panel5.setVisible(false);
						c.remove(panel5);
					}
				}
			}

		});

		spelllist1.addListSelectionListener(new ListSelectionListener() {
			@Override
			public void valueChanged(ListSelectionEvent e) {
				if (!e.getValueIsAdjusting()) {
					if (spelllist1.getSelectedIndex() != -1) {
						model1.remove(spelllist1.getSelectedIndex());
						c.add(panel2).setLocation(100, 0);
						panel2.add(j).setLocation(255, 90);
						panel2.setVisible(true);

						;
					}
				}
			}

		});

		spelllist2.addListSelectionListener(new ListSelectionListener() {
			@Override
			public void valueChanged(ListSelectionEvent e) {
				if (!e.getValueIsAdjusting()) {
					if (spelllist2.getSelectedIndex() != -1) {
						model2.remove(spelllist2.getSelectedIndex());
						c.add(panel3).setLocation(100, 0);
						panel3.add(j2).setLocation(255, 90);
						panel3.setVisible(true);

						;

					}
				}
			}

		});

		spelllist3.addListSelectionListener(new ListSelectionListener() {
			@Override
			public void valueChanged(ListSelectionEvent e) {
				if (!e.getValueIsAdjusting()) {
					if (spelllist3.getSelectedIndex() != -1) {
						model3.remove(spelllist3.getSelectedIndex());
						c.add(panel4).setLocation(100, 0);
						panel4.add(j3).setLocation(255, 90);
						panel4.setVisible(true);

						;
					}
				}
			}

		});

		spelllist4.addListSelectionListener(new ListSelectionListener() {
			@Override
			public void valueChanged(ListSelectionEvent e) {
				if (!e.getValueIsAdjusting()) {
					if (spelllist4.getSelectedIndex() != -1) {
						model4.remove(spelllist4.getSelectedIndex());
						c.add(panel5).setLocation(100 , 0);
						panel5.add(j4).setLocation(255, 90);
						panel5.setVisible(true);

						;

					}
				}
			}

		});

		mainView.setVisible(true);

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getActionCommand().equals("Quit"))
			System.exit(0);
		if (e.getActionCommand().equals("finish")) {

			if (name1.getText().equals("") || name2.getText().equals("") || name3.getText().equals("")
					|| name4.getText().equals(""))
				JOptionPane.showMessageDialog(null, "Please enter the champions name");

			String s1, s2, s3, s4;
			if (spelllist1.getModel().getSize() < 3 || spelllist2.getModel().getSize() < 3
					|| spelllist2.getModel().getSize() < 3 || spelllist2.getModel().getSize() < 3)
				// pop up window to be implemented

				JOptionPane.showMessageDialog(null, "You should choose 3 spells for every champion");

			else {
				
				
				s1 = name1.getText();
				Wizard cur;
				cur = new HufflepuffWizard(s1);
				tr.addChampion((Champion) cur);
				for (int i = 0; i < (spelllist1.getModel().getSize()); i++) {
					cur.getSpells().add((Spell) (spelllist1.getModel().getElementAt(i)));
				}

				s2 = name2.getText();
				cur = new GryffindorWizard(s2);
				tr.addChampion((Champion) cur);
				for (int i = 0; i < (spelllist1.getModel().getSize()); i++) {
					cur.getSpells().add((Spell) (spelllist1.getModel().getElementAt(i)));
				}

				s3 = name3.getText();
				cur = new SlytherinWizard(s3);

				tr.addChampion((Champion) cur);
				for (int i = 0; i < (spelllist1.getModel().getSize()); i++) {
					cur.getSpells().add((Spell) (spelllist1.getModel().getElementAt(i)));
				}

				s4 = name4.getText();
				cur = new RavenclawWizard(s4);
				tr.addChampion((Champion) cur);
				for (int i = 0; i < (spelllist1.getModel().getSize()); i++) {
					cur.getSpells().add((Spell) (spelllist1.getModel().getElementAt(i)));
				}

				try {
					tr.beginTournament();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				try {
					mainView.dispose();
					controller = new Controller(tr);
				} catch (IOException e2) {
					e2.printStackTrace();
				}

			}
		}
	}

	@Override
	public void onFinishingFirstTask(ArrayList<Champion> winners) throws IOException {
		// TODO Auto-generated method stub

	}

	@Override
	public void onFinishingSecondTask(ArrayList<Champion> winners) throws IOException {
		// TODO Auto-generated method stub

	}

	@Override
	public void onFinishingThirdTask(Champion winner) {
		// TODO Auto-generated method stub

	}

	public static void main(String[] args) throws IOException {
		// initialize the supermarket GUI

		new TournamentGUI();
	}

	private Spell[] toArray(ArrayList<Spell> arr) {
		Spell[] res = new Spell[arr.size()];
		for (int i = 0; i < res.length; i++) {
			res[i] = arr.get(i);
		}
		return res;
	}

}