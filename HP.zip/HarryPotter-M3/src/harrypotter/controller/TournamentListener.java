package harrypotter.controller;

public interface TournamentListener {

	public void onFinishingFirst(int n);
}
