package harrypotter.controller;

import java.awt.Graphics;
import java.awt.Image;
import java.util.Vector;

import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.ListModel;

public class ImageList<E> extends JList {
	private static final long serialVersionUID = 1L;
	private Image image = null;
	private int iWidth2;
	private int iHeight2;

	public ImageList( final E[] listData ,Image image) {
		super(listData);
		this.image = image;
		this.iWidth2 = image.getWidth(this) / 2;
		this.iHeight2 = image.getHeight(this) / 2;
	}

	public void paintComponent(Graphics g) {
		g.drawImage(image, 0, 0, getWidth(), getHeight(), this);
		super.paintComponent(g);
	       
	}

}
